This unsupported member is a synthetic omission example.
